/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask1;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class ICETASK1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bird brd = new Bird(0, "", 0);
        System.out.println("Enter details for the bird:");
        brd.input();

        Reptile rept = new Reptile(0, "", 0.0);
        System.out.println("Enter details for the reptile:");
        rept.input();

        System.out.println("\nBird details:");
        brd.output();

        System.out.println("\nReptile details:");
        rept.output();
    }
    
}
class Animal {
    protected int IDtag;
    protected String species;

    public Animal(int IDtag, String species) {
        this.IDtag = IDtag;
        this.species = species;
    }

    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter ID tag: ");
        IDtag = scanner.nextInt();
        scanner.nextLine(); // Consume the newline
        System.out.print("Enter species: ");
        species = scanner.nextLine();
    }

    public void output() {
        System.out.println("ID Tag: " + IDtag);
        System.out.println("Species: " + species);
    }
}
class Bird extends Animal {
    private int featherColor;

    public Bird(int IDtag, String species, int featherColor) {
        super(IDtag, species);
        this.featherColor = featherColor;
    }

    @Override
    public void input() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter feather color (1=grey, 2=white, 3=black): ");
        featherColor = scanner.nextInt();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("Feather Color: " + getFeatherColorName());
    }

    private String getFeatherColorName() {
        switch (featherColor) {
            case 1:
                return "Grey";
            case 2:
                return "White";
            case 3:
                return "Black";
            default:
                return "Unknown";
        }
    }
}

class Reptile extends Animal {
    private double bloodTemp;

    public Reptile(int IDtag, String species, double bloodTemp) {
        super(IDtag, species);
        this.bloodTemp = bloodTemp;
    }

    @Override
    public void input() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter blood temperature: ");
        bloodTemp = scanner.nextDouble();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("Blood Temperature: " + bloodTemp);
    }
}
//Student Number-ST10373357

